#ifndef LCDML_DISP_MENU
    #define LCDML_DISP_MENU
    #include <Arduino.h>
    #include <LCDMenuLib2.h>
    //#include <LCDML_display_menu.cpp>

    //void lcdml_menu_clear();
    //void lcdml_menu_display();

#endif
#ifndef LCDML_DISP_MENU_F
    #define LCDML_DISP_MENU_F
    #include <Arduino.h>
    #include <LCDMenuLib2.h>
    //#include <LCDML_display_menuFunction.cpp>
    
    void mFunc_thread_start(uint8_t);
    void mFunc_thread_stop(uint8_t);
    void mFunc_information(uint8_t);
    void mFunc_timer_info(uint8_t);
    void mFunc_p2(uint8_t);
    void mFunc_back(uint8_t);
    void mFunc_screensaver(uint8_t);
    void mFunc_goToRootMenu(uint8_t);
    void mFunc_jumpTo_timer_info(uint8_t);
    void mFunc_para(uint8_t);

#endif
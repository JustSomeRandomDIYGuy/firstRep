#ifndef LCDML_DISP_DNYF
    #define LCDML_DISP_DNYF
    #include <Arduino.h>
    #include <LCDMenuLib2.h>
    //#include <LCDML_display_dynFunction.cpp>

    void mDyn_para(uint8_t);

#endif
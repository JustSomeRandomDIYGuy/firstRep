#ifndef LCDML_CONDITION
    #define LCDML_CONDITION
    #include <Arduino.h>
    #include <LCDMenuLib2.h>
    
    bool COND_hide();
    
    //#include <LCDML_condition.cpp>

#endif
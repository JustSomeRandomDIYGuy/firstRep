#ifndef TASK_SCHEDULER_CODE
    #define TASK_SCHEDULER_CODE
    #include <Arduino.h>
    #include <LCDMenuLib2.h>

    //#include <TaskSchedulerCode.cpp>

    void Task_Serial_Blink_Example();
    void Task_input_check();
    void Task_LCDMenuLib();

#endif